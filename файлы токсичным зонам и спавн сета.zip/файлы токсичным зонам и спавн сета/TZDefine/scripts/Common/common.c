// For other mods to use

#define TOXICZONE
//#define TZDEBUG
