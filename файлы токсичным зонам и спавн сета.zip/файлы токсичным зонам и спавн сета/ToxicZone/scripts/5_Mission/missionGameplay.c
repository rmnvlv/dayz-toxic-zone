modded class MissionGameplay extends MissionBase
{
	void MissionGameplay()
	{
		m_TZToxicZoneCore = NULL;
		GetTZToxicZoneCore();
	}
};
