class ToxicM18SmokeGrenade_Red extends ToxicSmokeBase
{
	void ToxicM18SmokeGrenade_Red()
	{
		SetParticleSmokeStart(ParticleList.GRENADE_M18_RED_START);
		SetParticleSmokeLoop(ParticleList.GRENADE_M18_RED_LOOP);
		SetParticleSmokeEnd(ParticleList.GRENADE_M18_RED_END);
	}
}

class ToxicM18SmokeGrenade_Green extends ToxicSmokeBase
{
	void ToxicM18SmokeGrenade_Green()
	{
		SetParticleSmokeStart(ParticleList.GRENADE_M18_GREEN_START);
		SetParticleSmokeLoop(ParticleList.GRENADE_M18_GREEN_LOOP);
		SetParticleSmokeEnd(ParticleList.GRENADE_M18_GREEN_END);
	}
}

class ToxicM18SmokeGrenade_Purple extends ToxicSmokeBase
{
	void ToxicM18SmokeGrenade_Purple()
	{
		SetParticleSmokeStart(ParticleList.GRENADE_M18_PURPLE_START);
		SetParticleSmokeLoop(ParticleList.GRENADE_M18_PURPLE_LOOP);
		SetParticleSmokeEnd(ParticleList.GRENADE_M18_PURPLE_END);
	}
}

class ToxicM18SmokeGrenade_Yellow extends ToxicSmokeBase
{
	void ToxicM18SmokeGrenade_Yellow()
	{
		SetParticleSmokeStart(ParticleList.GRENADE_M18_YELLOW_START);
		SetParticleSmokeLoop(ParticleList.GRENADE_M18_YELLOW_LOOP);
		SetParticleSmokeEnd(ParticleList.GRENADE_M18_YELLOW_END);
	}
}

class ToxicM18SmokeGrenade_White extends ToxicSmokeBase
{
	void ToxicM18SmokeGrenade_White()
	{
		SetParticleSmokeStart(ParticleList.GRENADE_M18_WHITE_START);
		SetParticleSmokeLoop(ParticleList.GRENADE_M18_WHITE_LOOP);
		SetParticleSmokeEnd(ParticleList.GRENADE_M18_WHITE_END);
	}
}
