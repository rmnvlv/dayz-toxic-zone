enum ToxicAgents
{
	//agent list
	TOXICSICKNESS		= 1098;
}
