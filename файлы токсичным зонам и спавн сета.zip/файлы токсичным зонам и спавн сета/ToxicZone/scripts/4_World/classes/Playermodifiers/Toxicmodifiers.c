enum ToxicModifiers
{
  MDF_TOXICSICKNESS = 1998,
  MDF_TOXICCURE,
}
