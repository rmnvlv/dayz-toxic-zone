modded class ParticleList
{
	static const int TOXICZONE_GREENSMOKE = RegisterParticle( "ToxicZone_Data/particles/" , "GreenSmoke");
	static const int TOXICZONE_BLUESMOKE = RegisterParticle( "ToxicZone_Data/particles/" , "BlueSmoke");
	static const int TOXICZONE_GREYSMOKE = RegisterParticle( "ToxicZone_Data/particles/" , "GreySmoke");
	static const int TOXICZONE_REDSMOKE = RegisterParticle( "ToxicZone_Data/particles/" , "RedSmoke");
	static const int TOXICZONE_GREENSMOKE2 = RegisterParticle( "ToxicZone_Data/particles/" , "GreenSmoke2");
	static const int TOXICZONE_MUSTARDSMOKE = RegisterParticle( "ToxicZone_Data/particles/" , "MustardSmoke");
	static const int TOXICZONE_WHITESMOKE = RegisterParticle( "ToxicZone_Data/particles/" , "WhiteSmoke");
	static const int TOXICZONE_PURPLESMOKE = RegisterParticle( "ToxicZone_Data/particles/" , "PurpleSmoke");
	static const int TOXICZONE_GREENSPORE = RegisterParticle( "ToxicZone_Data/particles/" , "GreenSpore");
	static const int TOXICZONE_BLUESPORE = RegisterParticle( "ToxicZone_Data/particles/" , "BlueSpore");
	static const int TOXICZONE_REDSPORE = RegisterParticle( "ToxicZone_Data/particles/" , "RedSpore");
	static const int TOXICZONE_MUSTARDSPORE = RegisterParticle( "ToxicZone_Data/particles/" , "MustardSpore");
	static const int TOXICZONE_WHITESPORE = RegisterParticle( "ToxicZone_Data/particles/" , "WhiteSpore");
	static const int TOXICZONE_PURPLESPORE = RegisterParticle( "ToxicZone_Data/particles/" , "PurpleSpore");
}
